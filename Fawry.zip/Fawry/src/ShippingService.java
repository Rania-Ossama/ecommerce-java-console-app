import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShippingService {
    public static void ship(List<Shippable> items) {
        if (items == null || items.isEmpty()) {
            System.out.println("No items to ship.");
            return;
        }

        System.out.println("** Shipment notice **");
        Map<String, Integer> nameCount = new HashMap<String, Integer>();
        Map<String, Double> weightMap = new HashMap<String, Double>();
        double totalWeight = 0.0;
        for (Shippable item : items) {
            String name = item.get_name();
            double weight = item.getWeight();

            nameCount.put(name, nameCount.getOrDefault(name, 0) + 1);
            weightMap.put(name, weight);
            totalWeight += weight;
        }

        for (String name : nameCount.keySet()) {
            int count = nameCount.get(name);
            double weight = weightMap.get(name);
            System.out.printf("%dx %s\t%.0fg\n", count, name, weight * count);
        }

        System.out.printf("Total package weight %.1fkg\n", totalWeight / 1000.0);
        System.out.println();
    }
}
