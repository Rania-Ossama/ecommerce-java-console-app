public class Product {
    private String name;
    private double price;
    private int quantity;

    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String get_name() {
        return name;
    }

    public double get_price() {
        return price;
    }

    public int get_quantity() {
        return quantity;
    }


}
