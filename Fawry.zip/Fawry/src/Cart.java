import java.util.ArrayList;
import java.util.List;

public class Cart {
    private List<CartItem> items;

    public Cart() {
        items = new ArrayList<>();
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void clear() {
        items.clear();
    }

    public void addProduct(Product product, int quantity) {
        if (quantity > product.get_quantity()) {
            throw new IllegalArgumentException("Not enough quantity available.");
        }

        if (product instanceof ExpirableProduct) {
            ExpirableProduct exp = (ExpirableProduct) product;
            if (exp.isExpired()) {
                throw new IllegalStateException("Product " + product.get_name() + " is expired.");
            }
        }

        for (CartItem item : items) {
            if (item.getProduct().equals(product)) {
                item.increaseAmount(quantity);
                return;
            }
        }

        items.add(new CartItem(product, quantity));
    }
}

