import java.time.LocalDate;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        ExpirableProduct cheese = new ExpirableProduct("Cheese", 100, 10, LocalDate.of(2025, 12, 1), 200);
        ExpirableProduct biscuits = new ExpirableProduct("Biscuits", 75, 5, LocalDate.of(2026, 12, 15), 300);
        NonExpirableProduct tv = new NonExpirableProduct("TV", 8000, 2, 7000);
        NonExpirableProduct card = new NonExpirableProduct("Scratch Card", 50, 10);

        Customer rania = new Customer("Rania", 10000);
        Cart cart = new Cart();

        cart.addProduct(cheese, 2);
        cart.addProduct(biscuits, 1);
        cart.addProduct(tv, 1);
        cart.addProduct(card, 3);


        try {
            OrderProcessor.checkout(rania, cart);
        } catch (Exception e) {
            System.out.println("Checkout failed: " + e.getMessage());
        }


    }
}