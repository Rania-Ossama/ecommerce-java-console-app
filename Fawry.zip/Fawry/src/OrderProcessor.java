import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderProcessor {

    public static void checkout(Customer customer, Cart cart) {

        if (cart.isEmpty()) {
            throw new IllegalStateException("Cart is empty.");
        }

        double subtotal = 0;
        double totalWeight = 0;
        List<Shippable> itemsToShip = new ArrayList<>();

        for (CartItem item : cart.getItems()) {
            Product product = item.getProduct();
            int quantity = item.getAmount();
            double itemTotal = product.get_price() * quantity;
            subtotal += itemTotal;

            if (product instanceof Shippable) {
                Shippable shippable = (Shippable) product;
                for (int i = 0; i < quantity; i++) {
                    itemsToShip.add(shippable);
                    totalWeight += shippable.getWeight();
                }
            }
        }

        double shippingFees = Math.ceil(totalWeight / 1000.0) * 30;

        double total = subtotal + shippingFees;

        if (customer.getBalance() < total) {
            throw new IllegalStateException("Customer has insufficient balance.");
        }

        customer.deductBalance(total);

        if (!itemsToShip.isEmpty()) {
            System.out.println("** Shipment notice **");
            Map<String, Integer> nameCount = new HashMap<>();
            Map<String, Double> weightMap = new HashMap<>();

            for (Shippable s : itemsToShip) {
                String name = s.get_name();
                nameCount.put(name, nameCount.getOrDefault(name, 0) + 1);
                weightMap.put(name, s.getWeight());
            }

            for (String name : nameCount.keySet()) {
                System.out.printf("%dx %s\t%.0fg\n", nameCount.get(name), name, weightMap.get(name));
            }

            System.out.printf("Total package weight %.1fkg\n\n", totalWeight / 1000.0);
        }

        System.out.println("** Checkout receipt **");
        for (CartItem item : cart.getItems()) {
            System.out.printf("%dx %s\t%.0f\n", item.getAmount(), item.getProduct().get_name(), item.totalPrice());
        }

        System.out.println("----------------------");
        System.out.printf("Subtotal\t%.0f\n", subtotal);
        System.out.printf("Shipping\t%.0f\n", shippingFees);
        System.out.printf("Amount\t\t%.0f\n", total);
        System.out.printf("Balance\t\t%.0f\n", customer.getBalance());

        cart.clear();
    }
}
