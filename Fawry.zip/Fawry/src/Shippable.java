public interface Shippable {
    public String get_name();
    public double getWeight();
}
