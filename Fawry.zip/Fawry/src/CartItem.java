public class CartItem {
    private Product product;
    private int amount;

    public CartItem(Product product, int amount) {
        this.product = product;
        this.amount = amount;
    }

    public Product getProduct() {
        return product;
    }

    public int getAmount() {
        return amount;
    }

    public void increaseAmount(int amount1) {
        this.amount += amount1;
    }

    public double totalPrice() {
        return product.get_price() * amount;
    }
}
